Name: Emily Chen
Section: 17694
UFL email: em.chen@ufl.edu
System: Windows 11
Compiler: MinGW
SFML version: 3
IDE: CLion
Other notes: None